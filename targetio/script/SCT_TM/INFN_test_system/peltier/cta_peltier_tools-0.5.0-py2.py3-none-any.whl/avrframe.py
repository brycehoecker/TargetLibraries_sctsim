#!/usr/bin/env python

import crc_ccitt

__author__ = 'Sterling Peet'
__author_email__ = 'sterling.peet@ae.gatech.edu'
__date__ = '2020-08-05'
__version__ = '0.5.0'

FIGN = 0xC1
FEND = 0xC0
FESC = 0xDB
TFEND = 0xDC
TFESC = 0xDD
TFIGN = 0xDE

MESSAGE_MIN_LEN = 2


def escape(b_array):
    """
    Remove bytes with special meaning from the stream.  This should only
    be done once, on the bytearray that is getting framed.
    """
    out_array = bytearray()
    for b in b_array:
        if b == FEND:
            out_array.append(FESC)
            out_array.append(TFEND)
        elif b == FESC:
            out_array.append(FESC)
            out_array.append(TFESC)
        elif b == FIGN:
            out_array.append(FESC)
            out_array.append(TFIGN)
        else:
            out_array.append(b)
    return out_array


def unescape(b_array):
    """
    Remove the escape sequences from a bytearray, and replace them with
    the original bytes.  This should only be done once, during the
    deframing process, before checking the validity of the CRC.
    """
    out_array = bytearray()
    flag = False
    for b in b_array:
        if flag:
            flag = False
            if b == TFEND:
                out_array.append(FEND)
            elif b == TFESC:
                out_array.append(FESC)
            elif b == TFIGN:
                out_array.append(FIGN)
            else:
                raise ValueError  # TODO: Drop frame silently or send to counter
        elif b == FESC:
            flag = True
        else:
            out_array.append(b)
    return out_array


def frame(b_array):
    b_array = bytearray([b for b in b_array])
    b_array = crc_ccitt.append_crc(b_array)
    b_array = escape(b_array)
    b_array.insert(0, FEND)
    b_array.append(FEND)
    return b_array


class deframer():
    """
    Bytes are fed into this class by calling the object with the next
    byte as the argument.  When a frame is successfully extracted from
    the byte stream, it calls the callback with the extracted frame as
    the argument.

    If frames without good CRC values are desired, the entire frame
    contents with the bad CRC (but after removing escaped sequences) is
    handed to the bad_crc_callback.  By default, it will quietly discard
    bad frames, but this allows a path to debug or even just count up
    failed frames.
    """

    def __init__(self, callback=None, bad_crc_callback=None):
        self.callback = callback
        self.bad_crc_callback = bad_crc_callback
        self.msg = bytearray()

        if callback is None:
            self.callback = self.null_callback
        if bad_crc_callback is None:
            self.bad_crc_callback = self.null_callback

    def null_callback(self, msg):
        """
        This is the default callback, which does nothing, in case the
        programmer doesn't want to know about something.  (And
        specifically we are making it easier to program internally)
        """
        pass

    def __call__(self, msg_byte):
        """
        This object is called with the individual bytes that come from
        a non-delimeted stream.  Ultimately, when delimiters occur, the
        frame gets processed and this object will call the given
        callback.
        """
        if type(msg_byte) is str:
            msg_byte = ord(msg_byte)
        if msg_byte == FEND:
            if len(self.msg) > MESSAGE_MIN_LEN:
                raw_msg = unescape(self.msg)
                if crc_ccitt.check_crc(raw_msg):
                    # print "message crc 0x{:02x}{:02x}".format(raw_msg[-2], raw_msg[-1])
                    self.callback(raw_msg[:-2])
                    # print "Calling Callback"
                else:
                    # print "Calling Bad CRC Callback"
                    self.bad_crc_callback(raw_msg)
            else:
                if len(self.msg) > 0:
                    # Otherwise consecutive 0xC0 bytes just means the
                    # buffer is empty on the far side.
                    print("Throw an exception, message too short")
            self.msg = bytearray()
        elif msg_byte == FIGN:
            pass  # TODO: write this to a counter variable
        else:
            self.msg.append(msg_byte)


if __name__ == '__main__':
    import binascii
    a = bytearray([0xCC, 0xDE, 0xFF, 0xDB, 0xC0, 0xAA, 0x33, 0x76])
    print(binascii.hexlify(a))
    b = escape(a)
    print(binascii.hexlify(b))
    print(binascii.hexlify(unescape(b)))
    print(binascii.hexlify(frame(b)))
