__author__ = 'Sterling Peet'
__author_email__ = 'sterling.peet@ae.gatech.edu'
__date__ = '2020-08-05'
__version__ = '0.5.0'


class call_back(object):
    '''
    This is now officially a hack, it has been copied around to
    different places **WAY** too many times.
    '''

    def __init__(self):
        self.done_flag = False
        self.msg_out = None

    def __call__(self, msg):
        self.done_flag = True
        self.msg_out = msg
        # print(msg)


class pelttlm(object):
    '''
    A class that will handle decoding and understanding of pelttlm
    formatted messages.
    '''

    def __init__(self):
        self.done_flag = False
        self.msg_out = None
        self.address = None
        self.mode = None
        self.status = None
        self.text_buffer_len = 0
        self.timer_count = None
        self.opcode = None
        self.params = None

    def __call__(self, msg):
        '''
        Calling this object as a function will cause it to attempt
        to decode the message as a pelttlm message.  If you are trying
        to feed bytes to the object until a message pops out, you should
        instead use the feed() method.
        '''
        self.done_flag = True
        self.msg_out = msg
        if len(msg) >= 7:
            self.address = msg[0]
            self.mode = msg[1]
            self.status = msg[2]
            self.text_buffer_len = msg[3]
            self.timer_count = (msg[4] << 8) | msg[5]
            self.opcode = msg[6]
        if len(msg) == 11:
            self.params = [b for b in msg[7:11]]

    def __str__(self):
        str_list = []
        par_list = []
        str_list.append('Address Byte: {}'.format(self.address))
        str_list.append('Mode: {}'.format(self.mode))
        str_list.append('Status Code: 0x{:02X}'.format(self.status))
        str_list.append('Text Buffer Length: {}'.format(self.text_buffer_len))
        str_list.append('Timer Count: {}'.format(self.timer_count))
        str_list.append('OpCode: 0x{:02X}'.format(self.opcode))
        if len(self.params) > 0:
            par_list.append('[ ')
            for i in range(len(self.params)):
                par_list.append('0x{:02X} '.format(self.params[i]))
            par_list.append(']')
        str_list.append('Parameter: {}'.format(''.join(par_list)))
        ret = 'pelttlm message:'
        for s in str_list:
            ret += '\n * {}'.format(s)
        return ret

    def feed(self, byte):
        '''
        Take in a byte at a time, and feed it to the decoder until
        a frame/message pops out.  Currently not implemented.
        '''
        pass
