import argparse
import textwrap

from avrcmd import FUSE_TIMEOUT
from avrcmd import HOST
from avrcmd import HOST0
from avrcmd import PORT
from avrcmd import PORT0
from avrcmd import RDY_BUSY_TIMEOUT
from avrcmd import AVRcmd
from avrcmd import Read_Signature_Byte
from avrcmd import __date__
from avrcmd import __version__
from avrcmd import nullByte

parser = argparse.ArgumentParser(
    description=textwrap.dedent('''\
        Use this program to send individual commands to the AVR in programming mode.
        Refer to page 301 of the Atmel ATmega328 datasheet.'''),
    formatter_class=argparse.RawDescriptionHelpFormatter,
    epilog=textwrap.dedent('''\
        Written by Sterling Peet <sterling.peet@gatech.edu>, under
        Nepomuk Otte <http://otte.gatech.edu>
        Center for Relativistic Astrophysics
        Georgia Institute of Technology
        Atlanta, GA, USA'''))
# version='%(prog)s {version}, ({date})'.format(version=__version__,
# date=__date__))
parser.add_argument(
    'byte1', default=Read_Signature_Byte, nargs='?',
    help='Byte 1 of AVR Programming Instruction')
parser.add_argument(
    'byte2', default=nullByte, nargs='?',
    help='Byte 2 of AVR Programming Instruction')
parser.add_argument(
    'byte3', default=nullByte, nargs='?',
    help='Byte 3 of AVR Programming Instruction')
parser.add_argument(
    'byte4', default=nullByte, nargs='?',
    help='Byte 4 of AVR Programming Instruction')
parser.add_argument(
    '-V', '--version', action='version',
    version='%(prog)s {version}, ({date})'.format(version=__version__,
                                                  date=__date__))
parser.add_argument(
    '-e', '--erase', action='store_true',
    help='Erase the chip\'s memory before running instruction')
parser.add_argument(
    '-d', '--dry_run', action='store_true',
    help='Display hex commands instead of running them')
parser.add_argument(
    '-u', '--unsafe', action='store_true',
    help='Disable safety check for using unsafe AVR instructions')
parser.add_argument(
    '-v', '--verbose', action='count',
    help='Increase output verbosity')
parser.add_argument(
    '--target_host', default=HOST,
    help='IP address of the TARGET fpga')
parser.add_argument(
    "--target_port", default=PORT, type=int,
    help='Port the TARGET fpga is listening on')
parser.add_argument(
    '--rx_port', default=PORT0, type=int,
    help='Local port to listen on for TARGET response packets')
parser.add_argument(
    '--fuse_timeout', default=FUSE_TIMEOUT, type=int,
    help='How long the user has to recognize a fuse error and abort writing')
parser.add_argument(
    '--r_lfuse', action='store_true',
    help='Read Low Fuses')
parser.add_argument(
    '--r_hfuse', action='store_true',
    help='Read High Fuses')
parser.add_argument(
    '--r_efuse', action='store_true',
    help='Read Extended Fuses')
parser.add_argument(
    '--w_lfuse', default='None', help='Write Low Fuses')
parser.add_argument(
    '--w_hfuse', default='None', help='Write High Fuses')
parser.add_argument(
    '--w_efuse', default='None',
    help='Write Extended Fuses')
parser.add_argument(
    '--rdy_bsy_timeout', default=RDY_BUSY_TIMEOUT, type=int,
    help='Length of time to wait for uC while it indicates it is busy')
parser.add_argument(
    '--load_pgm_word', action='store_true',
    help='Load a 16-bit word into the flash program memory using a full length \
    address specified in the byte1 argument and 16-bit word specified in the \
    byte2 argument.')
parser.add_argument(
    '--read_pgm_word', action='store_true',
    help='Read a 16-bit word out of the flash program memory from the address \
    specified in the byte1 argument')
parser.add_argument(
    '--verify_pgm_word', action='store_true',
    help='Check the word in the flash memory at the address specified in the \
    byte1 argument and find out if it matches the word specified in the byte2 \
    argument.')
parser.add_argument(
    '--write_pgm_page', action='store_true',
    help='Write the contents of the program memory page buffer to the page \
    that begins at the address specified in the byte1 argument')
parser.add_argument(
    '-s', '--start_pgm_mode', action='store_true',
    help='Ensure programming mode is active before attempting to run command')
parser.add_argument(
    '--end_pgm_mode', action='store_true',
    help='Exit programming mode and remove the reset signal from the AVR')


def main(args=None):
    args = parser.parse_args(args=args)

    avr = AVRcmd(args.target_host, args.target_port, HOST0, args.rx_port)
    if args.dry_run:
        avr.dryRun = True
    avr.printPacketInfo = args.verbose
    avr.readyBusyTimeout = args.rdy_bsy_timeout

    # Start programming mode if requested
    if args.start_pgm_mode:
        print('** Starting AVR Programming Mode')
        avr.startPgmMode()

    # TODO: Investigate the Device Signature

    # Investigate the Fuses
    if args.r_lfuse or (args.w_lfuse != 'None'):
        print('Reading Low Fuse Byte:')
        lowByte = avr.responseByte('0x50', nullByte, nullByte, nullByte)
        print('Low Fuse Byte:', hex(lowByte))

    if args.w_lfuse != 'None':
        print('Writing Low Fuse Byte:', args.w_lfuse)
        avr.writeFuse('0xAC', '0xA0', args.w_lfuse, args.fuse_timeout)
        print('Reading Low Fuse Byte:')
        lowByte = avr.responseByte('0x50', nullByte, nullByte, nullByte)
        print('Low Fuse Byte:', hex(lowByte))

    if args.r_hfuse or (args.w_hfuse != 'None'):
        print('Reading High Fuse Byte:')
        highByte = avr.responseByte('0x58', '0x08', nullByte, nullByte)
        print('High Fuse Byte:', hex(highByte))

    if args.w_hfuse != 'None':
        print('Writing High Fuse Byte:', args.w_hfuse)
        avr.writeFuse('0xAC', '0xA8', args.w_hfuse, args.fuse_timeout)
        print('Reading High Fuse Byte:')
        highByte = avr.responseByte('0x58', '0x08', nullByte, nullByte)
        print('High Fuse Byte:', hex(highByte))

    if args.r_efuse or (args.w_efuse != 'None'):
        print('Reading Extended Fuse Byte:')
        extendedByte = avr.responseByte('0x50', '0x08', nullByte, nullByte)
        print('Extended Fuse Byte:', hex(extendedByte))

    if args.w_efuse != 'None':
        print('Writing Extended Fuse Byte:', args.w_efuse)
        avr.writeFuse('0xAC', '0xA4', args.w_efuse, args.fuse_timeout)
        print('Reading Extended Fuse Byte:')
        extendedByte = avr.responseByte('0x50', '0x08', nullByte, nullByte)
        print('Extended Fuse Byte:', hex(extendedByte))

    # Erase Chip's Memory
    if args.erase:
        print('** Running Unsafe Command!')
        print('** Erasing Memory...')
        avr.chipErase()
        print('** Done.')

    if args.verify_pgm_word:
        print('Verifying word', args.byte2, 'in address', args.byte1)
        result = avr.verifyFlashWord(eval(args.byte1), eval(args.byte2))
        if result:
            print('Successfully Verified.')
        else:
            print('Word does not match', hex(
                avr.readFlashWord(eval(args.byte1))))
    elif args.read_pgm_word:
        print('Reading word in address', args.byte1)
        word = avr.readFlashWord(eval(args.byte1))
        print('Word:', hex(word))
    elif args.load_pgm_word:
        print('Loading word', args.byte2, 'into address', args.byte1, '(',
              hex(eval(args.byte1) & 0x3F), ')')
        avr.loadFlashWord(eval(args.byte1), eval(args.byte2))
    elif args.write_pgm_page:
        print('Writing page buffer to page', hex(eval(args.byte1) & (~0x003F)),
              'containing address', args.byte1)
        avr.writeFlashPage(eval(args.byte1))
    else:
        # Run user's command!
        command = avr.packBytes(args.byte1, args.byte2, args.byte3, args.byte4)
        print("* cmd     :", hex(command))
        if args.unsafe:
            print('** Running Unsafe Command!')
            avr.unSafe()
        result = avr.cmd(command)
        if args.verbose > 0:
            print("* out word:", hex(result))
        print("* out byte: ", hex(avr.lastResponseByte))

    # If the user wanted to load or write something, we should make sure
    # the microcontroller is ready before we exit, otherwise a new call to
    # the same program could happen fast enough to corrupt data in the
    # microcontroller.
    if (args.unsafe or (eval(args.byte1) == 0x40) or
        (eval(args.byte1) == 0x48) or (eval(args.byte1) == 0x4C) or
        (eval(args.byte1) == 0x4D) or (eval(args.byte1) == 0xC0) or
        (eval(args.byte1) == 0xC1) or (eval(args.byte1) == 0xC2) or
            (eval(args.byte1) == 0xAC)):
        avr.waitUntilReady()

    if args.end_pgm_mode:
        print("** Exiting Programming Mode and removing reset signal!")
        avr.removeReset()
