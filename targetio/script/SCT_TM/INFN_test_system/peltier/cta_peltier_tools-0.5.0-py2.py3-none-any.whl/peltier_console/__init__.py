__author__ = 'Sterling Peet'
__author_email__ = 'sterling.peet@ae.gatech.edu'
__date__ = '2020-08-05'
__version__ = '0.5.0'
