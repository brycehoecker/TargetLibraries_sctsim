import argparse
import textwrap
from time import sleep

import avrcmd
from peltier_console import __date__
from peltier_console import __version__

ctlReg = 0x21  # 0x2f for Eval Board
ctlMode = 0x01

delayTime = 0.1

parser = argparse.ArgumentParser(
    description=textwrap.dedent(
        '''\
        Use this program to monitor the old-style PeltierPOST firmware.'''),
    formatter_class=argparse.RawDescriptionHelpFormatter,
    epilog=textwrap.dedent(
        '''\
        Written by Sterling Peet <sterling.peet@ae.gatech.edu>, under
        Nepomuk Otte <http://otte.gatech.edu>
        Center for Relativistic Astrophysics
        Georgia Institute of Technology
        Atlanta, GA, USA'''))

parser.add_argument(
    '--version', action='version',
    version='%(prog)s {version}, ({date})'.format(version=__version__,
                                                  date=__date__))
parser.add_argument(
    '--target_host', default=avrcmd.HOST,
    help='IP address of the TARGET fpga')
parser.add_argument(
    "--target_port", default=avrcmd.PORT, type=int,
    help='Port the TARGET fpga is listening on')
parser.add_argument(
    '--rx_port', default=avrcmd.PORT0, type=int,
    help='Local port to listen on for TARGET response packets')
# TODO: have option/flag to reset at beginning


def main(args=None):

    args = parser.parse_args(args=args)

    avr = avrcmd.AVRcmd(args.target_host, args.target_port,
                        avrcmd.HOST0, args.rx_port)
    ctl = avr.getFPGA()

    # Reset the uC to start the process
    avr.startPgmMode()
    sleep(1)
    avr.removeReset()
    sleep(1)

    print('\nTemperature controller serial console')
    print('Press CTRL + C to exit\n')

    speed = 0x20  # This has a low probability of transfer error by experiment
    sleep(1)

    # set up the uC
    ctl.sendCmd(ctlReg, 1, 0x2000, 0)
    sleep(delayTime)

    # Set up the uC SPI speed
    ctl.sendCmd(ctlReg, 1, (speed << 8 | ctlMode), 0)
    sleep(delayTime)

    thisLine = ""
    while True:
        try:
            results = [0, 0, 0, 0]
            # Reset uC buffer pointer
            avr.cmd(0xff)
            # Get 1st block of data (0x16 is SYN Idle)
            data = avr.cmd(0x0)
            results[0] = (data & 0xFF000000) >> 24
            results[1] = (data & 0x00FF0000) >> 16
            results[2] = (data & 0x0000FF00) >> 8
            results[3] = data & 0xFF

            byte = results[0]

            if byte >= 32 and byte <= 126:
                thisLine = thisLine + chr(byte)
            elif byte == 0xd:
                print("AVR: {}".format(thisLine))
                thisLine = ""
            # print thisLine

        except KeyboardInterrupt:
            print(thisLine)
            print("\n\n***")
            print("*** Shutting off FPGA Serial Console")
            print("***\n")
            exit()
