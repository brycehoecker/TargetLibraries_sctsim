import argparse
import struct
import textwrap

import avrcmd
import avrframe
from peltcmd import PeltierCmd
from peltcmd import __date__
from peltcmd import __version__
from peltcmd import cmd_response
from peltcmd import hex_byte

parser = argparse.ArgumentParser(
    description=textwrap.dedent(
        '''\
        Use this program to send individual commands to the Arduino-Based
        Peltier-Effect Thermal Control System for the CTA telescope focal
        plane.  These messages are sent in the avrframe format.'''),
    formatter_class=argparse.RawDescriptionHelpFormatter,
    epilog=textwrap.dedent(
        '''\
        Written by Sterling Peet <sterling.peet@ae.gatech.edu>, under
        Nepomuk Otte <http://otte.gatech.edu>
        Center for Relativistic Astrophysics
        Georgia Institute of Technology
        Atlanta, GA, USA'''))
parser.add_argument(
    '--version', action='version',
    version='%(prog)s {version}, ({date})'.format(version=__version__,
                                                  date=__date__))
parser.add_argument(
    'OpCode', default='0', nargs='?',
    help='OpCode to read from or write to')
parser.add_argument(
    'Parameter', default=None, nargs='?',
    help='Value to send in message as parameter to OpCode')
parser.add_argument(
    '--flush', action='store_true',
    help='Only receive bytes to flush the remote uC message buffer')
parser.add_argument(
    '--target_host', default=avrcmd.HOST,
    help='IP address of the TARGET fpga')
parser.add_argument(
    "--target_port", default=avrcmd.PORT, type=int,
    help='Port the TARGET fpga is listening on')
parser.add_argument(
    '--rx_port', default=avrcmd.PORT0, type=int,
    help='Local port to listen on for TARGET response packets')
parser.add_argument(
    '-w', '--write', action='store_true',
    help='Use the write flag to write a value to the OpCode')
parser.add_argument(
    '-t', '--timeout', default=2, type=float,
    help='Time in seconds to wait before giving up on a response')
group = parser.add_mutually_exclusive_group()
group.add_argument(
    "-v", "--verbosity", action="count", default=0,
    help='Verbose output. -v -v for more.')
group.add_argument(
    "-q", "--quiet", action="count", default=0,
    help='Quell progress output. -q -q for less.')


def main(args=None):
    args = parser.parse_args(args=args)

    avr = avrcmd.AVRcmd(args.target_host, args.target_port,
                        avrcmd.HOST0, args.rx_port)

    if args.flush:
        frame_to_send = []
    else:
        cmd = PeltierCmd(args.target_host)
        cmd.opcode(args.OpCode, args.write)
        if args.Parameter is not None:
            if not args.write:
                print('WARNING: Parameter Supplied, write bit not set...')
            cmd.param(args.Parameter)

        msg_to_send = cmd.msg()
        print(cmd)
        print('')
        frame_to_send = avrframe.frame(msg_to_send)
        print('avrframe bytes: {}'.format(' '.join([hex_byte(b) for b in frame_to_send])))
    tlm_msg = cmd_response(avr, frame_to_send, timeout=args.timeout)
    if tlm_msg is not None:
        print(tlm_msg)
        if len(tlm_msg.params) == 4:
            ret2 = '->Param (uint32): {}\n->Param  (float): {}'
            ipar = struct.unpack('!L', bytearray(tlm_msg.params))[0]
            fpar = struct.unpack('!f', bytearray(tlm_msg.params))[0]
            ret2 = ret2.format(ipar, fpar)
            print(ret2)
