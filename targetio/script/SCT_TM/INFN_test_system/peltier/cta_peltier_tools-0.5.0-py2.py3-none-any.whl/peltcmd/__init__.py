import ast
import struct
import time

import six

import avrcmd
import avrframe
import pelttlm

__author__ = 'Sterling Peet'
__author_email__ = 'sterling.peet@ae.gatech.edu'
__date__ = '2020-08-05'
__version__ = '0.5.0'


class frame_send_helper(object):
    def __init__(self, b_array):
        self.arr = b_array
        self.index = 0
        self.max = len(self.arr)

    def __call__(self):
        if self.index is self.max:
            return avrframe.FIGN
        else:
            b = self.arr[self.index]
            self.index += 1
            return b


def send_frame_blind(avr, b_array):
    '''
    Blindly send a frame to the uC without checking what is send back
    to the computer.'''
    ign = avrframe.FIGN
    ign_byte = '{}'.format(ign)
    for b in b_array:
        data_byte = '{}'.format(b)
        # This line determines where in the 4 byte transfer we put
        # our one byte of real data:
        avr.byteCmd(data_byte, ign_byte, ign_byte, ign_byte)
        time.sleep(avrcmd.minRequestResponseTime)


def cmd_response(avr, cmd, timeout=1.0, verbose=False):
    '''
    Send a peltcmd frame to the uC and wait for a response pelttlm frame
    to come back from the uC.  The timeout parameter is the time in
    seconds until giving up on recieving a valid response.
    '''
    next_byte = frame_send_helper(cmd)
    cback = pelttlm.call_back()
    deframe = avrframe.deframer(cback)
    tlm = pelttlm.pelttlm()
    ign = avrframe.FIGN
    ign_byte = '{}'.format(ign)
    msg_flag = False
    time_flag = False
    begin_time = time.time()
    while not msg_flag and not time_flag:
        if time.time() - begin_time > timeout:
            print("*** TIMEOUT WAITING FOR RESPONSE MESSAGE")
            time_flag = True
            # TODO: Raise an exception instead

        data_byte = '{}'.format(next_byte())
        # This line determines where in the 4 byte transfer we put
        # our one byte of real data:
        resp = avr.byteCmd(data_byte, ign_byte, ign_byte, ign_byte)
        time.sleep(avrcmd.minRequestResponseTime)
        # print(resp)
        deframe(resp['byte1'])
        if cback.done_flag:
            msg_flag = True
            tlm(cback.msg_out)
            return tlm


def hex_byte(b):
    ret = '{}'.format(hex(b)[2:])
    if len(ret) == 1:
        ret = '0' + ret
    return '0x' + ret


class PeltierCmd(object):
    '''
    An object for ecapsulating the process of formatting and sending
    commands to the Arduino-Based Peltier-Effect Thermal Control
    System for the CTA telescope focal plane.
    '''

    def __init__(self, address=None):
        self._opcode = self.opcode(None)
        self._params = []
        self._addr = self.address(address)

    def __extract_addr(self, addr):
        if isinstance(addr, six.integer_types):
            if addr >= 0 and addr <= 0xFF:
                self._addr = addr
            else:
                print('WARNING: Ignoring out of range address {}'.format(addr))
        elif isinstance(addr, (float)):
            self._addr = 0
        else:
            parts = addr.split('.')
            self.__extract_addr(eval(parts[-1]))

    def address(self, address=None):
        if address is None:
            self._addr = 0
        else:
            self.__extract_addr(address)
        return self._addr

    def opcode(self, opcode=None, write_bit=False):
        '''
        Set the opcode byte for the message.  This can be defined as
        either 0-255 integer value, a hex string defining a byte, or as
        as string from OpCode table.  Returns the raw integer opcode
        that has been set.
        '''
        self._opcode = 0
        if opcode is None:
            opcode = 0
        if isinstance(opcode, six.integer_types):
            if opcode >= 0 and opcode <= 0xFF:
                self._opcode = opcode
            else:
                print('WARNING: Ignoring out of range OpCode {}'.format(opcode))
        elif isinstance(opcode, (str)):
            self.opcode(eval(opcode))
        if write_bit:
            self._opcode |= 0x80  # set write bit
        else:
            self._opcode &= 0x7F  # defeat write bit
        return self._opcode

    def param(self, val, length=4):
        '''
        Add a parameter to the peltcmd message.  Unless specified
        otherwise it will be 4 bytes long.  Currently, only one
        parameter can be added to a message.
        '''
        self._params = []
        if isinstance(val, six.string_types):
            try:
                val = ast.literal_eval(val)
            except SyntaxError:
                pass
        if isinstance(val, six.integer_types):
            # TODO: Assume unsigned for now...
            if val >= 0:
                self._params = [b for b in struct.pack('!L', val)]
            else:
                self._params = [b for b in struct.pack('!l', val)]
        elif isinstance(val, float):
            self._params = [b for b in struct.pack('!f', val)]
        if len(self._params) > 0 and not isinstance(self._params[0], six.integer_types):
            for i in range(len(self._params)):
                self._params[i] = ord(self._params[i])

        return self._params

    def msg(self):
        '''Returns a bytearray with the raw peltcmd message.'''
        ret = bytearray()
        ret.append(self._addr)
        ret.append(self._opcode)
        for i in range(len(self._params)):
            ret.append(self._params[i])
        return ret

    def __str__(self):
        ret = 'peltcmd:\n->Address: {} (dec), {} (hex)\n->Opcode: {}\n'
        addr = self._addr
        h_addr = hex_byte(addr)
        op = hex_byte(self._opcode)
        if len(self._params) == 4:
            ret2 = ('->Param    (hex): {}\n->Param (uint32):'
                    ' {}\n->Param  (float): {}')
            hpar = ' '.join(['{},'.format(hex_byte(b))
                             for b in self._params])
            ipar = struct.unpack('!L', bytearray(self._params))[0]
            fpar = struct.unpack('!f', bytearray(self._params))[0]
            ret2 = ret2.format(hpar, ipar, fpar)
            ret += ret2
        ret += '\n->Message: {}'.format(' '.join([hex_byte(b)
                                                  for b in self.msg()]))
        return ret.format(addr, h_addr, op)
