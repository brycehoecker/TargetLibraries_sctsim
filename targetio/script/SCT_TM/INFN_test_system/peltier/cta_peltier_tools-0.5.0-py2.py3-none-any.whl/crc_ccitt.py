#!/usr/bin/env python

from ctypes import c_ubyte
from ctypes import c_ushort

__author__ = 'Sterling Peet'
__author_email__ = 'sterling.peet@ae.gatech.edu'
__date__ = '2020-08-05'
__version__ = '0.5.0'

CRC_CCITT_INIT = 0xFFFF


def crc_ccitt_update(crc, data):
    if type(crc) != c_ushort:
        crc = c_ushort(crc)
    if type(data) != c_ubyte:
        data = c_ubyte(data)

    data.value ^= crc.value & 0x00FF
    data.value ^= data.value << 4
    data = c_ushort(data.value)
    return c_ushort((((data.value << 8) | (crc.value >> 8))
                     ^ (data.value >> 4) ^ (data.value << 3)))


def append_crc(b_array):
    b_array = bytearray([b for b in b_array])
    crc = c_ushort(CRC_CCITT_INIT)
    for b in b_array:
        crc = crc_ccitt_update(crc.value, b)
    b_array.append(crc.value >> 8)
    b_array.append(crc.value & 0x00FF)
    return b_array


def check_crc(b_array):
    if len(b_array) < 3:
        return False
    crc = c_ushort((b_array[-2] << 8) | (b_array[-1] & 0xFF))
    crc_data = c_ushort(CRC_CCITT_INIT)
    for b in b_array[:-2]:
        crc_data = crc_ccitt_update(crc_data.value, b)
    return crc.value == crc_data.value


if __name__ == '__main__':
    import binascii
    print(crc_ccitt_update(0xFFFF, 0xFF))
    print(binascii.hexlify(append_crc(bytearray([0xDE, 0xAD, 0xBE, 0xEF]))))
