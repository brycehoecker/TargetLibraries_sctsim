"""
Module that contains the command line app.

Why does this file exist, and why not put this in __main__?

  You might be tempted to import things from __main__ later, but that will cause
  problems: the code will get executed twice:

  - When you run `python -mcta-avrprog` python will execute
    ``__main__.py`` as a script. That means there won't be any
    ``cta_avrprog.__main__`` in ``sys.modules``.
  - When you import __main__ it will get executed again (as a module) because
    there's no ``cta_avrprog.__main__`` in ``sys.modules``.

  Also see (1) from http://click.pocoo.org/5/setuptools/#setuptools-integration
"""
import argparse
import textwrap
from socket import timeout

from fpgacmd import DATA_0
from fpgacmd import HOST
from fpgacmd import HOST0
from fpgacmd import PORT
from fpgacmd import PORT0
from fpgacmd import REG_0
from fpgacmd import RSP_NONE
from fpgacmd import TIMEOUT
from fpgacmd import FPGAcmd
from fpgacmd import __date__
from fpgacmd import __version__
from fpgacmd import buffer

parser = argparse.ArgumentParser(
    description=textwrap.dedent('''\
        Use this program to send individual UDP packets to a CTA TARGET fpga and
        optionally display the response data.'''),
    formatter_class=argparse.RawDescriptionHelpFormatter,
    epilog=textwrap.dedent('''\
        The core of this program is based on Leonid\'s PGPcmd_udp.py program, but
        several modifications were made explicitly to allow this file to be a
        usable module for interfacing with the TARGET fpga programmatically.

        Written by Sterling Peet <sterling.peet@gatech.edu>, under
        Nepomuk Otte <http://otte.gatech.edu>
        Center for Relativistic Astrophysics
        Georgia Institute of Technology
        Atlanta, GA, USA'''), )
parser.add_argument(
    '-V', '--version', action='version',
    version='%(prog)s {version}, ({date})'.format(version=__version__, date=__date__))
parser.add_argument(
    'fpga_register', default=REG_0, nargs='?',
    help='Register of TARGET fpga to read/write.')
parser.add_argument(
    'data', default=DATA_0, nargs='?',
    help='The data value to write to the specified register.')
parser.add_argument(
    'response', default=RSP_NONE, nargs='?',
    help='Additional packet response, for trigger and calstrobe.')
parser.add_argument(
    '-w', '--write', action='store_true',
    help='Write to the register, rather than read.  Specifying this '
    'option overrides the default behavior of reading if VALUE is '
    'not provided, but writing if VALUE is provided.')
group = parser.add_mutually_exclusive_group()
group.add_argument(
    '-v', '--verbose', action='count', default=0,
    help='Increase output verbosity.')
group.add_argument(
    '-q', '--quiet', action='count', default=0,
    help='Decrease output verbosity.')
parser.add_argument(
    '-i', '--show_time', action='store_true',
    help='Display the time when sending UDP packet.')
parser.add_argument(
    '-t', '--timeout', default=TIMEOUT,
    help='UDP packet timeout in seconds')
parser.add_argument(
    '--target_host', default=HOST,
    help='IP address of the TARGET fpga.')
parser.add_argument(
    "--target_port", default=PORT, type=int,
    help='Port the TARGET fpga is listening on.')
parser.add_argument(
    '--rx_port', default=PORT0, type=int,
    help='Local port to listen on for TARGET response packets.')
parser.add_argument(
    '-d', '--data_out', action='store_true',
    help='Use this flag if you want %(prog)s to return the data '
    'response as the exit code. (Useful for shell scripting)')
parser.add_argument(
    '-b', '--buffer_size', default=buffer, type=int,
    help='UDP buffer size.')


def main(args=None):
    args = parser.parse_args(args=args)

    if args.quiet < 1:
        print("\n{}".format("-" * 40))
    if args.quiet < 2:
        print("{} ( -h for usage )".format(parser.prog))
        print("-" * 40)
    if args.verbose > 0:
        print("AGIS target assembly running on %s port %s" %
              (args.target_host, args.target_port))

    comm = FPGAcmd(args.target_host, args.target_port, HOST0, args.rx_port,
                   eval(args.timeout), args.buffer_size)

    if args.show_time:
        comm.show_time = True

    if args.write:
        readWrite = 1
    else:
        if eval(args.data) > 0:
            if eval(args.fpga_register) > 0:
                readWrite = 1
            else:
                readWrite = 0
        else:
            readWrite = 0

    if args.verbose > 0:
        print("\nOutgoing Packet Info:")
        if args.verbose > 2:
            print("Local Host Settings: {} on port {}".format(HOST0, args.rx_port))
        if args.verbose > 1:
            print("R/W: {}".format(readWrite))
        print("Register: {}".format(hex(eval(args.fpga_register))))
        if readWrite:
            print("Data to Write: {}".format(hex(eval(args.data))))
        if (args.verbose > 1) or (args.response != RSP_NONE):
            print("Response: {}".format(hex(eval(args.response))))
        if args.verbose > 1:
            print("UDP rx timeout (sec): {}".format(args.timeout))
        if args.verbose > 2:
            print("UDP rx buffer size: {}".format(args.buffer_size))

    try:
        if args.verbose > 1:
            print("Packet Byte Array:")
            comm.setPrintCmd(True)
        result = comm.sendCmd(eval(args.fpga_register), readWrite, eval(args.data),
                              eval(args.response))
        if args.verbose > 0:
            print("\nCommand Response Packet:")
            print("Serial Number: {}".format(result.get("SerNum")))
        if (args.verbose > 1) or ((args.quiet < 2) and
                                  (result.get("Errors") != "0x0")):
            print("Errors: {}".format(result.get("Errors")))
        if args.quiet < 1:
            print("Register: {}".format(result.get("Addr")))
        if args.quiet < 1:
            print("Data: {}".format(result.get("Data")))
        else:
            if args.quiet < 2:
                print(result.get("Data"))
        if args.verbose > 2:
            print("Tail: {}".format(result.get("Tail")))
            print("Protocol: {}".format(result.get("Protocol")))

    except timeout:
        if args.quiet < 3:
            print("\n***")
            print("*** Did not Recieve a valid response from the target within")
            print("*** the {} second timeout from {} on port {}.".format(args.timeout,
                                                                         args.target_host, args.rx_port))
            if args.verbose > 0:
                print("***")
                print("*** This could be caused by a lack of network connectivity,")
                print("*** possibly due to the phys43222 computer's network driver")
                print("*** problem (and thus the computer must be restarted).")
                print("*** It could also be caused by a disconnected fiber optic")
                print("*** cable, or the power to the FPGA could be faulty.  Check")
                print("*** the lights on the fiber network conversion box to ensure")
                print("*** they indicate a good connection.")
            print("***\n")
        exit(1)

    if args.data_out:
        exit(eval(result.get('Data')))
