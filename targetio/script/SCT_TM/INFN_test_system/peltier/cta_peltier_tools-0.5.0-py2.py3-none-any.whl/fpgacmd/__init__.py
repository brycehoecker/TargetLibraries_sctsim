from __future__ import unicode_literals

from datetime import datetime
from socket import AF_INET
from socket import SOCK_DGRAM
from socket import socket
from struct import unpack as struct_unpack
from sys import version_info as py_version
from time import sleep

__author__ = 'Sterling Peet'
__author_email__ = 'sterling.peet@gatech.edu'
__date__ = '2020-08-05'
__version__ = '0.5.0'

TIMEOUT = '1'
READ = 0
DATA_0 = '0'
REG_0 = DATA_0
RSP_NONE = '0'
HOST = "192.168.12.173"
HOST0 = "0.0.0.0"  # Apparently this works for linux, but 127.0.0.1 is necessary for mac?
PORT0 = 8106
PORT = 8105
buffer = 102400


class PeltierController(object):
    '''This object is used for controlling the state of the Peltier uC via
    the control register(s) in the FPGA.'''

    def __init__(self, fpga):
        self.__fpga = fpga
        self.__default_speed = 0x40
        self.__speed = 0
        self.__eval_register = 0x2f
        self.__production_register = 0x21
        self.__config_register = 0
        self.__spi_read_reg = 0
        self.__spi_write_reg = 0
        self.__spi_transfer_time = 0
        self.printPacketInfo = 0
        self.setupSleep = 0.005
        self.uCStartupTime = 0.2
        self.__setupPgm1 = 0x02
        self.__setupPgm2 = 0x03
        self.__removeReset = 0x07
        self.__normalSPI = 0x01
        self.__pgmModeSuccess = 0x5300
        self.setProductionEnv()
        self.setSpeed(self.__default_speed)

    def __config(self, mode):
        '''
        Returns the config register word for the desired mode byte.
        '''
        _mode = mode & 0x07
        return _mode + (self.__speed << 8)

    def setEvalEnv(self):
        '''
        Set the register numbers for communicating with the eval board.
        '''
        self.__config_register = self.__eval_register
        self.__spi_write_reg = self.__config_register + 1
        self.__spi_read_reg = self.__spi_write_reg + 1

    def setProductionEnv(self):
        '''
        Set the register numbers for communicating with the production
        FPGA board.
        '''
        self.__config_register = self.__production_register
        self.__spi_write_reg = self.__config_register + 1
        self.__spi_read_reg = self.__spi_write_reg + 1

    def setSpeed(self, speed):
        '''
        Set the communication speed for the SPI bus.  Speed is 250 ns
        times the speed argument, mod 256 (the lowest byte).
        '''
        self.__speed = speed & 0xFF
        self.__spi_transfer_time = 0.000000250 * 32 * self.__speed
        # Time buffer to make sure transfer completes properly before requesting
        #  the data back
        self.__spi_transfer_time = self.__spi_transfer_time * 4

    def transfer(self, word):
        '''
        Send a 32-bit word to the uC and get a 32-bit word back.
        '''
        self.__fpga.write(self.__spi_write_reg, word)
        sleep(self.__spi_transfer_time)
        return self.__fpga.read(self.__spi_read_reg)

    def __checkPgmStatus(self):
        '''
        Check and see if the status is complete, the speed matches our
        expectations, and we are in programming mode.
        '''
        config = self.__fpga.read(self.__config_register)
        speedOK = False
        complete = False
        modeOK = False
        if self.__speed == ((config & 0xFF00) >> 8):
            speedOK = True
        if (config >> 31) > 0:
            complete = True
        if self.__setupPgm2 == (config & 0xFF):
            modeOK = True
        return speedOK and complete and modeOK

    def programmingMode(self):
        '''
        Put the Peltier uC into programming mode, allowing the part to
        be reprogrammed.
        '''
        # First Check if we are not already in Programming Mode
        if not self.__checkPgmStatus():
            # Try putting the FPGA in uC programming Mode
            if self.printPacketInfo > 0:
                print('*** Sending packets to Put FPGA in uC Programming Mode')
            self.__fpga.write(self.__config_register,
                              self.__config(self.__setupPgm1))

            sleep(self.setupSleep)  # Let the setting stick

            self.__fpga.write(self.__config_register,
                              self.__config(self.__setupPgm2))
            sleep(0.1)  # sleep(t_startup) # Give everything a chance to set up

            if self.__checkPgmStatus():
                if self.printPacketInfo > 0:
                    print(
                        '*** FPGA entered command mode: {}'.format(hex(self.__fpga.lastData)))
                # Double check we also got a good response from the uC
                resp = self.__fpga.read(self.__spi_read_reg)
                if resp != 0x5300:
                    print(
                        '*** AVR did NOT respond Correctly for Programming Mode! {}'.format(hex(resp)))
                    print('*** This usually happens if the wrong environment is used,')
                    print(
                        '***   production on an EVAL board, or EVAl on a real Front End.')
                else:
                    if self.printPacketInfo > 0:
                        print(
                            '*** AVR responded with Programming Mode Enabled: {}'.format(hex(resp)))
            else:
                print('*** FPGA did not go into uC Programming Mode!')
        else:
            if self.printPacketInfo > 0:
                print('*** FPGA was already in Programming Mode.')

    def normalMode(self):
        '''Put the Peltier uC into normal SPI communication mode.'''
        config = self.__fpga.read(self.__config_register)
        mode = config & 0xFF
        speed = (config & 0xFF00) >> 8
        if self.printPacketInfo > 0:
            print('*** Setting Peltier uC to normal mode')
            print('*** Peltier Config Read: {}'.format(hex(config)))
            print('*** Extracted Mode: {}'.format(hex(mode)))
            print('*** Extracted Speed: {}'.format(hex(speed)))

        if (mode == 0x01) or (speed != self.__speed):
            if self.printPacketInfo > 0:
                print('*** Mode or speed mismatch:')
                print('*** Mode  (wanted): {}'.format(hex(0x01)))
                print('*** Speed (wanted): {}'.format(hex(self.__speed)))
            if mode > 0x01:
                if self.printPacketInfo > 0:
                    print('*** Mode was greater than 0x01, resetting uC...')
                self.__fpga.write(self.__config_register, self.__config(0x07))
                sleep(self.setupSleep)
            self.__fpga.write(self.__config_register, self.__config(0))
            sleep(self.setupSleep)
            self.__fpga.write(self.__config_register, self.__config(1))
            sleep(self.setupSleep)
            if self.printPacketInfo > 1:
                config = self.__fpga.read(self.__config_register)
                print('*** Fresh uC config register: {}'.format(hex(config)))
            if mode > 0x01:
                sleep(self.uCStartupTime)

    def isNormalMode(self):
        '''Check to see if the uC is in normal run mode.'''
        config = self.__fpga.read(self.__config_register)
        mode = config & 0xFF
        if mode == 0x01:
            return True
        return False


class SterlingCmdBuild(object):
    '''
    This class is based heavily upon LeonidCmdBuild, but with
    some minor fixes to make it function as part of an importable
    module.
    '''

    def __init__(self, address, readWrite, data, response=None):
        self.__address = address
        self.__readWrite = readWrite
        self.__data = data
        self.__response = response
        self.__cmd = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

    def __setWrd0(self, data):
        return ((data & 0xFF000000) >> 24)

    def __setWrd1(self, data):
        return ((data & 0x00FF0000) >> 16)

    def __setWrd2(self, data):
        return ((data & 0x0000FF00) >> 8)

    def __setWrd3(self, data):
        return ((data & 0x000000FF) >> 0)

    def __setCmd(self, address, readWrite, data):
        cmdWord0 = 0x12345678
        cmdWord1 = ((readWrite & 1) << 30) + (address & 0x00ffffff)
        cmdWord2 = (data & 0xffffffff)
        cmdWord3 = 0xdeadbeef
        word0 = (self.__setWrd0(cmdWord0))
        word1 = (self.__setWrd1(cmdWord0))
        word2 = (self.__setWrd2(cmdWord0))
        word3 = (self.__setWrd3(cmdWord0))
        word4 = (self.__setWrd0(cmdWord1))
        word5 = (self.__setWrd1(cmdWord1))
        word6 = (self.__setWrd2(cmdWord1))
        word7 = (self.__setWrd3(cmdWord1))
        word8 = (self.__setWrd0(cmdWord2))
        word9 = (self.__setWrd1(cmdWord2))
        word10 = (self.__setWrd2(cmdWord2))
        word11 = (self.__setWrd3(cmdWord2))
        word12 = (self.__setWrd0(cmdWord3))
        word13 = (self.__setWrd1(cmdWord3))
        word14 = (self.__setWrd2(cmdWord3))
        word15 = (self.__setWrd3(cmdWord3))
        self.__cmd = [word0, word1, word2, word3, word4, word5, word6, word7,
                      word8, word9, word10, word11, word12, word13, word14, word15]

    def getCmd(self):
        self.__setCmd(self.__address, self.__readWrite, self.__data)
        return self.__cmd


class FPGAcmd(object):
    '''
    The FPGAcmd class is designed to be a wrapper for the generic
    UDP interface used to communicate with the TARGET evaluation board.
    '''

    def __init__(self, targetIP, targetPort, localHost, localPort,
                 udpTimeout, receiveBufferLength):
        self.__printCmd = False
        self._targetIP = targetIP
        self._targetPort = targetPort
        self._localHost = localHost
        self._localPort = localPort
        self.__updTimeout = udpTimeout
        self.__receiveBuf = receiveBufferLength
        self._UDPSock = socket(AF_INET, SOCK_DGRAM)
        self._connected = False
        self.writeRegister = 1
        self.readRegister = 0
        self.responseTrue = 1
        self.responseFalse = 0
        self.show_time = False
        self.printPacketInfo = 0
        self.lastSerialNum = 0
        self.lastWrite = False
        self.lastAddress = 0
        self.lastData = 0
        self.lastErrors = 0
        self.lastTimeoutError = False
        self.lastOtherError = False
        self.lastTail = 0
        self.lastProtocol = 0

    def setPrintCmd(self, boolean):
        '''
        True prints the command packet byte array before sending the
        packet, False prevents printing to stdout.
        '''
        self.__printCmd = boolean

    def __waitForResponse(self, responseLength=16):
        '''
        This is the response handling portion lifted directly from
        Leonid's PGPcmd_udp.py script.  I (Sterling) don't need this
        functionality, so programmatic access will require some refactoring
        to suit.
        '''
        print()
        print()
        still_data = 1
        k = 0
        n = 0
        # b0 = 0
        # b1 = 0

        if responseLength > 16:
            while (still_data):
                tmp = self._UDPSock.recvfrom(buffer)
                if len(tmp) == 2:
                    data, addr = tmp
                else:
                    print("timed out, bailing")
                    break
                # for i in range(len(data)):
                    # ptint 'Protocol data ', hex(ord(data[i]))
                k = k + 1
                n = n + 1
                if len(data) == 0:
                    still_data = 0
                if (k > 0):
                    # print 'Reply from: ', addr, data
                    # LeonidRspPrint(responseLength, data)
                    for i in range(len(data)):
                        # if(b0 <= 1000):
                        if ((i % 2) == 0):
                            print('Protocol data {} {} {}'.format(
                                k, i / 2, hex((((ord(data[i + 1])))) + ((ord(data[i])) << 8))))
                    #     if(b1 <= 1):
                    #         print 'Protocol data ', k, hex(ord(data[i]))
                    #     if(i == 3):
                    #         if((ord(data[i]) & 0x3) == 1):
                    #             b0 = b0 + 1
                    #         if((ord(data[i]) & 0x3) == 2):
                    #             b1 = b1 + 1
                    #             print 'Protocol data ', k, hex(ord(data[i]))
                    #     if (n%64) == 0:
                    # if (n>1500):
                    #     print 'Count ', n, b0, b1

    def sendCmd(self, register, readWrite, data, response):
        '''
        Send a command to the TARGET, which should repond to the
        command.  The contents of the response are extracted from the
        message, then loaded into a dictionary as text string keys and
        text string hex values.
        '''

        # nullResponse = '0';
        # SerNum = nullResponse  # TODO: Use this to check for missing packets!
        # Addr = nullResponse
        # DataBack = nullResponse
        # RegData0 = nullResponse
        # RegData1 = nullResponse
        # Tail = nullResponse
        # Protocol = nullResponse
        if not self._connected:
            self._UDPSock.bind((self._localHost, self._localPort))
            self._UDPSock.settimeout(self.__updTimeout)

        if readWrite == 0:
            responseLength = 16
        else:
            responseLength = 16

        if response == 0:
            responseLength = responseLength
        else:
            responseLength = 10000 * 10

        a4 = bytearray()
        a = SterlingCmdBuild(register, readWrite, data, response)
        for i in a.getCmd():
            a4.append(i)  # a4 += chr(i)

        if self.__printCmd:
            print(a.getCmd())

        if self.show_time:
            sendTime = datetime.now()
            print('Packet Departure: {} {}'.format(
                str(sendTime), sendTime.strftime('%Z')))

        self._UDPSock.sendto(a4, (self._targetIP, self._targetPort))

        if responseLength > 0:
            rawdata, addr = self._UDPSock.recvfrom(self.__receiveBuf)

            data = None
            zero = chr(0)
            if py_version[0] > 2:
                zero = 0

            if type(data) is str:
                data = [ord(c) for c in rawdata]
            else:
                data = rawdata

            self.lastSerialNum = self.__packInt(
                data[0], data[1], data[2], data[3])
            if py_version[0] > 2:
                self.lastWrite = (data[4] & 0x40) == 0x40
            else:
                self.lastWrite = (ord(data[4]) & 0x40) == 0x40
            self.lastAddress = self.__packInt(zero, data[5], data[6], data[7])
            self.lastData = self.__packInt(
                data[8], data[9], data[10], data[11])
            self.lastErrors = self.__packInt(zero, zero, data[12], data[13])
            self.lastTimeoutError = (self.lastErrors & 0x02) == 0x02
            self.lastOtherError = (self.lastErrors & 0x01) == 0x01
            self.lastTail = self.__packInt(zero, zero, data[14], data[15])

            if len(data) > 16:
                self.lastProtocol = 0
                for i in range(len(data) - 16):
                    self.lastProtocol = self.lastProtocol << 8
                    self.lastProtocol = self.lastProtocol + ord(data[i + 16])

    # In the event of the terriby unlikely:
        if response:
            self.__waitForResponse()

        return {'SerNum': hex(self.lastSerialNum), 'Addr': hex(self.lastAddress),
                'Data': hex(self.lastData), 'Errors': hex(self.lastErrors),
                'Tail': hex(self.lastTail), 'Protocol': hex(self.lastProtocol),
                'RawData': rawdata}

    def __packInt(self, byte0, byte1, byte2, byte3):
        '''Pack up string characters into 32-bit integer words.'''
        ret = None
        if py_version[0] > 2:
            arr = bytes([byte0, byte1, byte2, byte3])
            ret = struct_unpack('>I', arr)[0]
        else:
            _byte0 = ord(byte0) << 24
            _byte1 = ord(byte1) << 16
            _byte2 = ord(byte2) << 8
            _byte3 = ord(byte3)
            ret = _byte0 + _byte1 + _byte2 + _byte3
        return ret

    def read(self, register):
        '''Read the contents of the specified FPGA register.'''
        self.sendCmd(register, self.readRegister, self.readRegister,
                     self.responseFalse)
        if self.printPacketInfo > 1:
            print('FPGA Reading Register: {}'.format(hex(register)))
            print('Read {} from {}'.format(hex(self.lastData), hex(register)))
        return self.lastData

    def write(self, register, value):
        '''Write the value to the specified FPGA register.'''
        if self.printPacketInfo > 1:
            print('FPGA Writing {} to register {}'.format(
                hex(value), hex(register)))
            self.sendCmd(register, self.writeRegister,
                         value, self.responseFalse)

    def __del__(self):
        self._UDPSock.close()
