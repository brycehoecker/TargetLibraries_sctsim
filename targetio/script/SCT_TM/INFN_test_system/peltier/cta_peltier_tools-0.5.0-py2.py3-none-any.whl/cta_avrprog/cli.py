"""
Module that contains the command line app.

Why does this file exist, and why not put this in __main__?

  You might be tempted to import things from __main__ later, but that will cause
  problems: the code will get executed twice:

  - When you run `python -mcta-avrprog` python will execute
    ``__main__.py`` as a script. That means there won't be any
    ``cta_avrprog.__main__`` in ``sys.modules``.
  - When you import __main__ it will get executed again (as a module) because
    there's no ``cta_avrprog.__main__`` in ``sys.modules``.

  Also see (1) from http://click.pocoo.org/5/setuptools/#setuptools-integration
"""
import argparse
import textwrap

import intelhex
from progressbar import ETA
from progressbar import Bar
from progressbar import Percentage

import avrcmd
from cta_avrprog import AtmelProgrammer
from cta_avrprog import FileTransferSpeed1024
from cta_avrprog import TimeProgressBar
from cta_avrprog import __date__
from cta_avrprog import __version__

HOST = "192.168.12.173"
HOST0 = "0.0.0.0"  # Apparently this works for linux, but 127.0.0.1 is necessary for mac?
PORT0 = 8106
PORT = 8105

parser = argparse.ArgumentParser(
    description=textwrap.dedent('''\
        UDP based FPGA programmer mechanism for loading application code into the
        module\'s ATmega temperature controller uC.

        Example Invocation:\n

        %(prog)s -p m328 -U flash:w:blink.hex
        '''),
    formatter_class=argparse.RawDescriptionHelpFormatter,
    epilog=textwrap.dedent('''\
        This program is intended to run in place of the open source firmware loading
        tool /'avrdude/'.

        Written by Sterling Peet <sterling.peet@gatech.edu>, under
        Nepomuk Otte <http://otte.gatech.edu>
        Center for Relativistic Astrophysics
        Georgia Institute of Technology
        Atlanta, GA, USA'''))
parser.add_argument(
    '--version', action='version',
    version='%(prog)s {version}, ({date})'.format(version=__version__,
                                                  date=__date__))
parser.add_argument(
    '--target_host', default=HOST,
    help='IP address of the TARGET fpga')
parser.add_argument(
    "--target_port", default=PORT, type=int,
    help='Port the TARGET fpga is listening on')
parser.add_argument(
    '--rx_port', default=PORT0, type=int,
    help='Local port to listen on for TARGET response packets')
parser.add_argument(
    '-U', '--upload',
    help='<memtype>:r|w|v:<filename>[:format] Memory operation specification. \
    Only write/verify flash is currently supported.')
parser.add_argument(
    '-p', '--partno',
    help='This option is not needed, it provides compatibility with avrdude.')
parser.add_argument(
    '-n', '--no_write', action='store_true',
    help='Do not write anything to the device.')
parser.add_argument(
    '-V', '--no_verify', action='store_true',
    help='Do not verify.')
group = parser.add_mutually_exclusive_group()
group.add_argument(
    "-v", "--verbosity", action="count", default=0,
    help='Verbose output. -v -v for more.')
group.add_argument(
    "-q", "--quiet", action="count", default=0,
    help='Quell progress output. -q -q for less.')
parser.add_argument(
    '-C',
    help='This option is not needed, it provides compatibility with avrdude.')
parser.add_argument(
    '-c',
    help='This option is not needed, it provides compatibility with avrdude.')
parser.add_argument(
    '-P',
    help='This option is not needed, it provides compatibility with avrdude.')


def main(args=None):
    args = parser.parse_args(args=args)

    memUpload = []
    if args.upload is not None:
        memUpload = args.upload.split(':')

    avr = avrcmd.AVRcmd(args.target_host, args.target_port,
                        HOST0, args.rx_port)
    if args.no_write:
        avr.dryRun = True

    if len(memUpload) > 2:
        if memUpload[0] == 'flash':
            hexFile = intelhex.IntelHex16bit(memUpload[2])
            firmware = hexFile.tobinarray()

            widgets = ['Progress: ', Percentage(), ' ', Bar(left='[', right=']'),
                       ' ', ETA(), ' ', FileTransferSpeed1024()]
            progress = TimeProgressBar(widgets=widgets)
            if args.quiet > 0:
                progress = None

            avrLoader = AtmelProgrammer(avr, firmware, progress)

            if memUpload[1] == 'w':
                avrLoader.loadFirmware()
                if not args.no_verify:
                    verifyPass = avrLoader.verifyFirmware()
            elif memUpload[1] == 'v':
                verifyPass = avrLoader.verifyFirmware()

            if verifyPass:
                print('Successfully Verified Memory')
            else:
                print('*** Memory does not match original firmware file!')
                raise Exception('Memory does not match original firmware file')

    avr.removeReset()
    print('\n')
